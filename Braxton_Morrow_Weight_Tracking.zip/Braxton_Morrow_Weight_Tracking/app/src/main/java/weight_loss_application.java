import android.view.View;

import java.sql;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class weight_loss_application {
    //Crud Application

    public static create userDatabase() {
        return database;
    }

    public static void createNewTable(userDatabase) {
        int userId;
        string username;
        string password;
        string fullname;
        string email;
        int dailyWeight;
        int goalWeight;
    };

    public void addOrEdit(view:View) {
        //create
        INSERT INTO<userDatabase()>(column1) {
            VALUES
                    (1,
                       username
                    )
        };
        INSERT INTO<userDatabase()>(column2) {
                VALUES
                        (1,
                                password
                        )
        };
        INSERT INTO<userDatabase()>(column3) {
                VALUES
                        (1,
                                fullname
                        )
        };
        INSERT INTO<userDatabase()>(column4) {
                VALUES
                        (1,
                                email
                        )
        };
        INSERT INTO<userDatabase()>(column5) {
                VALUES
                        (1,
                                dailyWeight
                        )
        };
        INSERT INTO<userDatabase()>(column6) {
                VALUES
                        (1,
                                goalWeight
                        )
        };

        //Read
        
        }
        ;
        Update() {

        }
        ;
        Delete() {

        }

    };

    public static void main(String[] args) {
        createNewTable();
    }
}